#!/bin/bash


 
       

           
     rm -rf postProcessing
   
   
          rm -rf processor* 
            
         rm -rf processor*/system/data.solverPerformance.*

       