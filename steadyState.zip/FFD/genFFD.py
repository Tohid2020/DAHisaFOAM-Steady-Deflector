import numpy as np

def returnBlockPoints(corners, nx, ny, nz):
    """
    Generate FFD control points grid between 8 corners:
    corners shape: 8 x 3
    nx, ny, nz = number of control points in i, j, k directions
    """
    points = np.zeros((nx, ny, nz, 3))
    for dim in range(3):
        edge1 = np.linspace(corners[0][dim], corners[4][dim], nx)
        edge2 = np.linspace(corners[1][dim], corners[5][dim], nx)
        edge3 = np.linspace(corners[2][dim], corners[6][dim], nx)
        edge4 = np.linspace(corners[3][dim], corners[7][dim], nx)

        for i in range(nx):
            edge5 = np.linspace(edge1[i], edge3[i], ny)
            edge6 = np.linspace(edge2[i], edge4[i], ny)
            for j in range(ny):
                edge7 = np.linspace(edge5[j], edge6[j], nz)
                points[i, j, :, dim] = edge7
    return points

def writeFFDPointsVTK(filename, points, nx, ny, nz):
    """
    Write points and lines of FFD lattice to VTK legacy file.
    points: numpy array shape (nx, ny, nz, 3)
    """
    total_points = nx * ny * nz
    
    # Helper function to convert 3D index to 1D index in points array
    def idx(i, j, k):
        return i + j * nx + k * nx * ny

    with open(filename, 'w') as f:
        f.write("# vtk DataFile Version 3.0\n")
        f.write("FFD control points with connectivity\n")
        f.write("ASCII\n")
        f.write("DATASET POLYDATA\n")
        f.write(f"POINTS {total_points} float\n")
        # Write all points
        for k in range(nz):
            for j in range(ny):
                for i in range(nx):
                    x, y, z = points[i, j, k]
                    f.write(f"{x} {y} {z}\n")

        # Now write lines connecting points along i, j, and k directions to visualize the lattice
        lines = []

        # Lines along i direction (nx - 1 lines per row and layer)
        for k in range(nz):
            for j in range(ny):
                for i in range(nx - 1):
                    lines.append([idx(i, j, k), idx(i + 1, j, k)])

        # Lines along j direction (ny - 1 lines per column and layer)
        for k in range(nz):
            for i in range(nx):
                for j in range(ny - 1):
                    lines.append([idx(i, j, k), idx(i, j + 1, k)])

        # Lines along k direction (nz - 1 lines per column and row)
        for j in range(ny):
            for i in range(nx):
                for k in range(nz - 1):
                    lines.append([idx(i, j, k), idx(i, j, k + 1)])

        total_lines = len(lines)
        size_lines = total_lines * 3  # each line: 2 points + 1 (count)

        f.write(f"LINES {total_lines} {size_lines}\n")
        for line in lines:
            f.write(f"2 {line[0]} {line[1]}\n")

# === Define your rectangle corners and parameters ===
# Given 4 points (front plane, z=0.052 m)
a = np.array([-1.555, 1.272, 0.052])
b = np.array([-1.272, 1.555, 0.052])
c = np.array([1.272, -1.555, 0.052])
d = np.array([1.555, -1.272, 0.052])

z_back = -0.052  # thickness direction back plane

nBlocks = 1
nx = 2 # control points along AC diagonal
ny = 10   # control points along BD diagonal
nz = 5 # 2 control points in thickness (Z) direction

corners = np.zeros((nBlocks, 8, 3))

# Back plane corners
corners[0, 0, :] = [a[0], a[1], z_back]
corners[0, 1, :] = [b[0], b[1], z_back]
corners[0, 2, :] = [c[0], c[1], z_back]
corners[0, 3, :] = [d[0], d[1], z_back]

# Front plane corners
corners[0, 4, :] = a
corners[0, 5, :] = b
corners[0, 6, :] = c
corners[0, 7, :] = d

# Generate FFD control points
points = returnBlockPoints(corners[0], nx, ny, nz)

# Write to VTK file with connectivity lines for clear visualization
vtkFileName = 'FFD_custom_rectangle_with_lines.vtk'
writeFFDPointsVTK(vtkFileName, points, nx, ny, nz)

print(f"FFD control points VTK file written to: {vtkFileName}")
